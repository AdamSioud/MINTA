import Foundation


let headers = ["content-type": "application/json",
               "x-api-key": "bd0d4303-daef-4ee8-ac44-5d4d7f4eed5f" ]


let url = URL(string: "https://api-eu1.tatum.io/v3/nft/mint")
guard let requestUrl = url else { fatalError() }
// Prepare URL Request Object
var request = URLRequest(url: requestUrl)


let parameters = [
  "chain": "SOL",
  "from": "GwauVfYYSdwNZmCCKJnabNW32ZYUNmEVx3orPsm2SzYR",
  "fromPrivateKey": "KuKRmWQSXqeGGoTkJsWJJFdf7mS5goyDssqeAJB8YcPdL8ukD7qHii7NCkV5NfbDvFF9L7BJnyHDyiktbcimk8h",
    "to": "8daGm4KfNS4d44KbF1CreR8RHbrq6yWTtLMiqu2Dxa1Z",
    "metadata": [
        "name": "ADAMSKI",
        "symbol": "ADAM",
        "sellerFeeBasisPoints": 0,
        "creators": ["address": GwauVfYYSdwNZmCCKJnabNW32ZYUNmEVx3orPsm2SzYR", "verified": 1, "share": 100],
        "uri": "https://www.nba.com/celtics/sites/celtics/files/tatum_27.jpg"
    ]
]
  as [String : Any]

let postData = JSONSerialization.data(withJSONObject: parameters, options: [])


request.httpMethod = "POST"
request.allHTTPHeaderFields = headers
request.httpBody = postData as Data


/// Perform HTTP Request
let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
        // Check for Error
        if let error = error {
            print("Error took place \(error)")
            return
        }
 
        // Convert HTTP Response Data to a String
        if let data = data, let dataString = String(data: data, encoding: .utf8) {
            print("Response data string:\n \(dataString)")
        }
}
task.resume()
