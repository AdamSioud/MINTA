How the login is made, some notes, and help!

Firstly the tutorial used to create the google login is 
https://www.youtube.com/watch?v=0ncKXZVaXOU 

Image guide  for swift and xcode 
https://www.simpleswiftguide.com/how-to-add-image-to-xcode-project-in-swiftui/


Packages 

https://github.com/firebase/firebase-ios-sdk 
https://github.com/google/GoogleSignIn-iOS 


Google sign firebase

https://firebase.google.com/docs/auth/ios/google-signin 

Solana SDK

Openlogin / Web3Auth

Custom Auth https://github.com/torusresearch/customauth-swift-sdk 
Verifiers https://docs.tor.us/customauth/verifiers


OAuth

https://oauth.net/2/ 
https://developers.google.com/identity/protocols/oauth2 
https://www.youtube.com/watch?v=xH6hAW3EqLk 
